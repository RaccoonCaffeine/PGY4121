import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { NavController } from '@ionic/angular';
import { Auth } from '@angular/fire/auth';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage {
  loginForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private router: NavController, private auth: Auth, private userService: UserService) { // Inyectar dependencias
   // Crear el formulario
    this.loginForm = this.formBuilder.group({
      // Campos del formulario:
      username: [
        '',
        [
          Validators.required, // Campo requerido
          Validators.minLength(15), // Mínimo 6 caracteres
          Validators.maxLength(50), // Máximo 15 caracteres
          Validators.email, // Formato email
        
        ],
      ],
      password: [
        '',
        [
          Validators.required, // Campo requerido
          Validators.minLength(6), // Mínimo 6 caracteres
          Validators.maxLength(15), // Máximo 15 caracteres
          Validators.pattern('^[a-zA-Z0-9]+$'), // Solo alfanumérico
        ],
      ],
    });
  }
  async onLogin(){
    if(this.loginForm.valid){
      const username = this.loginForm.get('username')?.value;
      const password = this.loginForm.get('password')?.value;
      try{
        await this.userService.login({email: username, password});
        console.log('Usuario logeado');
        this.router.navigateForward(['/home']);
      }catch(error){
        console.log('Error al logear el usuario', error);
      }
    }else{
      console.log('Formulario inválido');
    }
  }
}
