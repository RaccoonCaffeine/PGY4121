export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyC0t76MRPSP86QJt-fooZ3gAD9x9tYXTcg",
    authDomain: "fanic-parking.firebaseapp.com",
    projectId: "fanic-parking",
    storageBucket: "fanic-parking.firebasestorage.app",
    messagingSenderId: "224129702471",
    appId: "1:224129702471:web:7bdb741d28b7cc0c2baf62"
  }
};
